(() => {
  const root = typeof fragmentElement !== "undefined" && fragmentElement && fragmentElement.parentElement;
  if (!root) return;

  if (!root.dataset.dxpEnhance) {
    root.dataset.dxpEnhance = "true(() => {
  const root =
    typeof fragmentElement !== 'undefined' &&
    fragmentElement &&
    fragmentElement.parentElement;
  if (!root) return;

  if (!root.dataset.dxpEnhance) {
    root.dataset.dxpEnhance = 'true';

    const search = root.querySelector('input[data-dxp-search]');
    const isTyping = (e) => {
      const t = e.target;
      return (
        t &&
        (t.tagName === 'INPUT' ||
          t.tagName === 'TEXTAREA' ||
          t.isContentEditable)
      );
    };

    document.addEventListener('keydown', (e) => {
      if (e.key === '/' && !isTyping(e)) {
        if (search) {
          e.preventDefault();
          search.focus();
          search.select();
        }
      }
    });

    if (search) {
      search.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const q = search.value.trim();
          if (!q) return;
          alert('Searching: ' + q);
        }
      });
    }
  }

  const prefersReduced = window.matchMedia(
    '(prefers-reduced-motion: reduce)'
  ).matches;
  if (!prefersReduced) {
    root.querySelectorAll('.card').forEach((el, i) => {
      el.animate(
        [
          { transform: 'translateY(6px)', opacity: 0.001 },
          { transform: 'translateY(0)', opacity: 1 },
        ],
        { duration: 320, delay: 60 * i, easing: 'cubic-bezier(.2,.7,.2,1)' }
      );
    });
  }
})();


    const search = root.querySelector('input[data-dxp-search]');
    const isTyping = (e) => {
      const t = e.target;
      return t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
    };

    document.addEventListener("keydown", (e) => {
      if (e.key === "/" && !isTyping(e)) {
        if (search) {
          e.preventDefault();
          search.focus();
          search.select();
        }
      }
    });

    if (search) {
      search.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          const q = search.value.trim();
          if (!q) return;
          alert("Searching: " + q);
        }
      });
    }
  }

  const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!prefersReduced) {
    root.querySelectorAll(".card").forEach((el, i) => {
      el.animate(
        [{ transform: "translateY(6px)", opacity: 0.001 }, { transform: "translateY(0)", opacity: 1 }],
        { duration: 320, delay: 60 * i, easing: "cubic-bezier(.2,.7,.2,1)" }
      );
    });
  }
})();